import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import random
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report

#load the data and combine the separate tables
premierLeague2019 = pd.read_csv('2019PremierLeague.csv') 
Bundesliga2019 = pd.read_csv('2019Bundesliga.csv')
LaLiga2019 = pd.read_csv('2019LaLiga.csv')
Ligue12019 = pd.read_csv('2019Ligue1.csv')
serieA2019 = pd.read_csv('2019SerieA.csv')
allLeagues = pd.concat((premierLeague2019, Bundesliga2019, LaLiga2019, Ligue12019, serieA2019))
print(allLeagues.columns.values)
print(allLeagues.describe())

print(len(allLeagues)) #check length before dropping any values
print(allLeagues.isnull().sum()) #checking the data for nulls
allLeagues = allLeagues.dropna() 
print(len(allLeagues)) #no nulls found so none dropped, length did not change


print(list(allLeagues.columns.values)) #view all the columns present
#columns not determining position like name, nationality, team, the player id are dropped
allLeagues = allLeagues.drop(columns = ['name', 'nationality', 'team']) 

#target variable is position. assess how many players are registered in each position
positions = allLeagues.position.value_counts()
plt.subplots(figsize = (10,10))
positions.plot(kind = 'bar')
plt.title("Top 5 Leagues Position Distribution")
plt.xlabel("Position")
plt.ylabel("Number of Players")
#plt.show()

#current player name id has '$' so we rename it for easier formatting
allLeagues = allLeagues.rename(columns= {'_id/$oid' : 'playerID'})
print(allLeagues.duplicated('playerID').sum()) # there are no duplicate players

#want a boxplot to check for an anomylous number of  minutes
sns.boxplot(y = allLeagues['general_stats/time'])
#plt.show()

#distribution of the number of minutes available
plt.hist(allLeagues['general_stats/time'], bins = 10)
plt.title("Player Minutes Played")
plt.xlabel("Number Of Minutes")
plt.ylabel("Number of Players")
plt.show() #normally distributed

#rename to make columns easier to work with as original columsn have '/'
allLeagues = allLeagues.rename(columns= {'general_stats/time' : 'minsPlayed'})
allLeagues = allLeagues.rename(columns= {'general_stats/games' : 'apps'})

regularPlayers = allLeagues[allLeagues['apps'] > 20] #only want players with a significant number of appearances
allList = list(regularPlayers.columns.values)
print("All list =", allList)

#we also do not want to adjust percentage stats as they are already an average
nonAdjust = ['playerID', 'age', 'height', 'weight', 'position', 'minsPlayed', 'apps', 'passing_stats/Cmp%']
needToAdjust = []
for x in allList:
    if x not in nonAdjust:
        needToAdjust.append(x)

#divide these by 90 to get a per game average
for x in needToAdjust:
   regularPlayers[x] = (regularPlayers[x]/(regularPlayers['minsPlayed']/90))

#remove factors which I don't think will have and impact of player classification
regularPlayers.drop(columns = ['playerID', 'weight', 'apps', 'minsPlayed', 'general_stats/red_cards'], inplace = True)

def correlationFinder(data):
    '''
    produces a correlation heat map for all the variables. Allows us to identify multi colinearity
    '''
    corrmat = data.corr()
    plt.subplots(figsize=(10,10))
    mask = np.triu(np.ones_like(corrmat, dtype= bool))
    cmap = sns.diverging_palette(230,20, as_cmap=True)                                                                                                                                                      
    sns.heatmap(corrmat, annot=True, mask=mask, cmap=cmap)
    locs, labels = plt.xticks()
    plt.setp(labels, rotation = 30)
    plt.show() 
correlationFinder(regularPlayers)

#drop columns where there is a lot of multicolinearity
#potential dropped columns = #xG vs goals vs npg vs shots npXg | xA vs Assists vs Key Passes | Key passes vs PPA | Tackles vs Tackles won v tackles past v blocks vs interceptions |
# press vs defensive stats succ | Prog passes v final third passes  
regularPlayers = regularPlayers.drop(columns = ['offensive_stats/goals', 'offensive_stats/npg', 'offensive_stats/npxG', 'offensive_stats/shots', 'offensive_stats/assists', 'offensive_stats/key_passes','passing_stats/PPA', 'defensive_stats/TklW', 
'defensive_stats/Past', 'defensive_stats/Blocks', 'defensive_stats/Int','defensive_stats/Succ', 'passing_stats/1/3'])

#X values to do the classification and position is the target variable
X = regularPlayers.drop(columns = ['position'])
y = regularPlayers.position

#Split into testing and training data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=10)


#Random forrest classifier
clf = RandomForestClassifier(n_estimators=100, oob_score=True, max_depth=3, random_state=10)
#fit it to the training data 
clf.fit(X_train, y_train)
testPredictionRF = clf.predict(X_test)
print(y_test.value_counts())
RFConfusion = confusion_matrix(y_test, testPredictionRF) #create the confusion matrix

def confusionMAtrixPlotter(dataSource, word):
    '''
    turns the confustion matrix into and easier to analyse visualisation
    '''
    ax = sns.heatmap(dataSource, annot = True, cmap= 'Blues')
    ax.set_title('Seaborn Confusion Matrix for ' + word)
    ax.set_xlabel('\nPredicted Values')
    ax.set_ylabel('Actual Values ')
    ax.xaxis.set_ticklabels(['DF', 'FW', 'GK', 'MF'])
    ax.yaxis.set_ticklabels(['DF', 'FW', 'GK', 'MF'])
    plt.show()
confusionMAtrixPlotter(RFConfusion, 'Random Forrest')
#classification report is printed
print(classification_report(y_test, testPredictionRF))

#Support Vector Machine
clf2 = svm.SVC(gamma = 'auto', decision_function_shape= "ovo", kernel= 'linear')
clf2.fit(X_train, y_train)
testPreditionSVM = clf2.predict(X_test)
SVMConfusion = confusion_matrix(y_test, testPreditionSVM)
confusionMAtrixPlotter(SVMConfusion, 'SVM')
print("SVM score: ")
print(classification_report(y_test, testPreditionSVM))


#NEURAL NETWORK 
from sklearn.model_selection import GridSearchCV
random.seed(10)
param_grid = [
        {
            'activation' : ['identity', 'logistic', 'tanh', 'relu'],
            'solver' : ['lbfgs', 'sgd', 'adam'],
            'hidden_layer_sizes': [
             (1,),(2,),(3,),(4,),(5,),(6,),(7,),(8,),(9,),(10,),(11,), (12,),(13,),(14,),(15,),(16,),(17,),(18,),(19,),(20,),(21,)
             ]
        }
       ]
#Neural network - initially not converging so into a grid search
#clf3 = GridSearchCV(MLPClassifier(), param_grid, cv=3,scoring='accuracy')
#clf3.fit(X_train, y_train)
#print("Best parameters set found on development set:")
#print(clf3.best_params_)
'''{'activation': 'identity', 'hidden_layer_sizes': (3,), 'solver': 'lbfgs'}'''
clf3 = MLPClassifier(solver = "lbfgs", alpha = 1e-5, activation= "identity", hidden_layer_sizes = (3), random_state=10, learning_rate="adaptive", early_stopping=True, max_iter=1000)
clf3.fit(X_train, y_train)
testPreditionNN = clf3.predict(X_test)
NNConfusionMatrix = confusion_matrix(y_test, testPreditionNN)
confusionMAtrixPlotter(NNConfusionMatrix, 'Neural Netwrok')
print("NEURAL NETWORK SCORE: \n",classification_report(y_test, testPreditionNN))


#logistic regression
clf4 = LogisticRegression(solver='liblinear', random_state = 0)
clf4.fit(X_train, y_train)
testPreditionLR = clf4.predict(X_test)
LRConfusionMatrix = confusion_matrix(y_test, testPreditionLR)
print(LRConfusionMatrix)
confusionMAtrixPlotter(LRConfusionMatrix, 'LR')
print("LOGISTIC REGRESSION SCORE : \n",classification_report(y_test, testPreditionLR))

#find coefficients to find most important features
importance = clf2.coef_[0]
pot = list(X.columns)
ticks = [0,1,2,3,4,5,6,7,8,9,10,11,12]
for i,v in enumerate(importance):
    print("Feature: %0d, Score: %.5f" % (i,v))
print(X.columns)
plt.bar([x for x in range(len(importance))], importance)
plt.xticks(ticks, pot, rotation = 15)
plt.ylabel("coefficient")
plt.title("Coefficients/importance")
plt.tight_layout
plt.show()



